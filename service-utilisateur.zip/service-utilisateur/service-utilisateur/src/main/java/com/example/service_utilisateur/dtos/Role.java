package com.example.service_utilisateur.dtos;

public enum Role {
    CHERCHEUR,
   ADMINISTRATEUR,
    TECHNICIEN;
}
