package com.example.service_utilisateur.dtos;
public record UserRegistrationRecord(String username, String email,String firstName,String lastName,String password, String role) {
}
