package com.example.service_utilisateur.dtos;

public record ResetPassword(String password) {
}
