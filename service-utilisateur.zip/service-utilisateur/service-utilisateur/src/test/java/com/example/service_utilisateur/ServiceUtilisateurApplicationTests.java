package com.example.service_utilisateur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceUtilisateurApplicationTests {

	@Test
	void contextLoads() {
	}

}
